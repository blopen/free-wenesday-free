// @author: Ralph.Maurer@iet-gibb.ch
// Compilation: javac AB411_03_XOR.java
// Execution: java -jar AB411_03_XOR.jar
package xor_crypt;

import java.io.*;
import java.util.Scanner;

public class AB411_03_XOR {

    public static String encrypt(String text, int key) throws FileNotFoundException {
// wir werden die Zeichen einzeln codieren
        char[] zeichen = text.toCharArray();
// bitweise XOR-Verschlüsselung
        for (int i = 0; i < zeichen.length; i++) {
// Mit (char)int wandle int in einen char um
            zeichen[i] = (char) (zeichen[i] ^ key);
        }
// wir erzeugen aus dem Array vom Typ char einen String
        return new String(zeichen);
    }
}
