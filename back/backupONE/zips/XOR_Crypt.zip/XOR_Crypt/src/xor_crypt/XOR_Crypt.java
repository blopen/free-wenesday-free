/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xor_crypt;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author vmadmin
 */
public class XOR_Crypt {

    /**
     * @param args the command line arguments
     */
    // static String readDatei = "/home/vmadmin/Dokumente/Modul411/Gedicht.txt";
    // static String writeDatei = "/home/vmadmin/Dokumente/Modul411/ausgabe.txt";
    static String text = "";

    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        String key = args[0];
        String inputDatei = "/home/vmadmin/Dokumente/Modul411" + args[1];
        String outputDatei = "/home/vmadmin/Dokumente/Modul411" + args[2];
        readText(key, inputDatei);
        writeText(outputDatei);
    }

    static public void readText(String key, String inputDatei) throws FileNotFoundException {
        // Dateiverzeichnispfad zur auszulesenden Datei.    
        try (Scanner scn = new Scanner(new File(inputDatei), "UTF-8")) {
            while (scn.hasNextLine()) {
                text += AB411_03_XOR.encrypt(scn.nextLine(), Integer.parseInt(key));
            }
            System.out.println(text);
            scn.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    static public void writeText(String outputDatei) throws IOException {
        try {
            BufferedWriter myWriter = new BufferedWriter(new FileWriter(outputDatei, false));
            myWriter.write(text);
            myWriter.close();
        } catch (IOException eIO) {
            System.out.println("Folgender Fehler trat auf : " + eIO);
        }

    }

}
