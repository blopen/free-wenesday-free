/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package towdimensionalarray;

import java.util.*;
import java.lang.Math.*;

/**
 *
 * @author nelson.Lopez
 */
public class TowdimensionalArray {
    static int i2= 1000 , i1=1000;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        long startTime = System.currentTimeMillis();
        Print2DArray(MakeMatrix(i1, i2 ));
        long endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        System.out.println("Milisecunden: "+time);

    }
    public static int[][] MakeMatrix(int i1, int i2)
    {
        

        int tdArray[][] = new int[i1][i2];
        for(int i = 0; i< i1; i++){
            Random r = new Random();
            int val = r.nextInt(i2);
            
            Arrays.fill(tdArray[i], val);
            i2--;
        }
        return tdArray;
    }
    public static void Print2DArray(int[][] arr)
    {
        for(int i = 0; i < i1; i++)
        {
            for(int j = 0; j < i2; j++)
            {
            System.out.printf("%5d ", arr[i][j]);
            }
         System.out.println();
        }
    }
    
}
